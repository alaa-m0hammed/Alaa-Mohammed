"use client";
import { motion, useInView } from "framer-motion";
import { useRef } from "react";

const skills = [
  { name: "Python", level: 85, category: "backend" },
  { name: "FastAPI", level: 80, category: "backend" },
  { name: "Docker", level: 75, category: "backend" },
  { name: "Java", level: 80, category: "lang" },
  { name: "C++", level: 78, category: "lang" },
  { name: "SQL", level: 72, category: "data" },
  { name: "Data Engineering", level: 70, category: "data" },
  { name: "Data Cleaning", level: 75, category: "data" },
  { name: "Azure", level: 65, category: "data" },
  { name: "Problem Solving & Algorithms", level: 80, category: "cp" },
  { name: "JavaScript", level: 75, category: "frontend" },
  { name: "HTML/CSS", level: 85, category: "frontend" },
];

const categoryColor: Record<string, string> = {
  backend: "#1D9E75",
  lang: "#0F6E56",
  data: "#5DCAA5",
  frontend: "#9FE1CB",
  cp: "#085041",
};

function SkillBar({ name, level, category, index }: { name: string; level: number; category: string; index: number }) {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-50px" });

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, x: -20 }}
      animate={inView ? { opacity: 1, x: 0 } : {}}
      transition={{ duration: 0.5, delay: index * 0.06 }}
      style={{ marginBottom: "1.4rem" }}
    >
      <div style={{ marginBottom: "6px" }}>
        <span style={{ fontSize: "13px", color: "#e8f0ec", fontWeight: 500 }}>{name}</span>
      </div>
      <div style={{ height: "3px", background: "rgba(255,255,255,0.06)", borderRadius: "2px", overflow: "hidden" }}>
        <motion.div
          initial={{ width: 0 }}
          animate={inView ? { width: `${level}%` } : {}}
          transition={{ duration: 1, delay: index * 0.06 + 0.2, ease: "easeOut" as const }}
          style={{
            height: "100%", borderRadius: "2px",
            background: `linear-gradient(90deg, ${categoryColor[category]}, ${categoryColor[category]}88)`,
          }}
        />
      </div>
    </motion.div>
  );
}

export default function Skills() {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-80px" });

  return (
    <section id="skills" style={{ padding: "6rem 2.5rem", borderTop: "0.5px solid rgba(29,158,117,0.1)" }}>
      <div style={{ maxWidth: "780px", margin: "0 auto" }}>
        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          style={{ marginBottom: "3rem" }}
        >
          <p style={{
            fontFamily: "'JetBrains Mono', monospace",
            fontSize: "12px", color: "#1D9E75", letterSpacing: "0.12em", marginBottom: "0.6rem",
          }}>02. what I work with</p>
          <h2 style={{ fontSize: "32px", fontWeight: 600, color: "#e8f0ec", letterSpacing: "-0.02em" }}>
            skills
          </h2>
        </motion.div>

        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(300px, 1fr))", gap: "0 4rem" }}>
          {skills.map((skill, i) => (
            <SkillBar key={skill.name} {...skill} index={i} />
          ))}
        </div>
      </div>
    </section>
  );
}
