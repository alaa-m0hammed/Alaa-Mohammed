"use client";
import { motion, useInView } from "framer-motion";
import { useRef } from "react";
import { GitFork, Code2, Mail, Building2, ArrowUpRight } from "lucide-react";

const contacts = [
  {
    icon: GitFork,
    label: "github",
    value: "alaa-m0hammed",
    href: "https://github.com/alaa-m0hammed",
  },
  {
    icon: Code2,
    label: "codeforces",
    value: "BLOSSOM_12",
    href: "https://codeforces.com/profile/BLOSSOM_12",
  },
  {
    icon: Building2,
    label: "training",
    value: "DEPI — Data Engineering",
    href: "#",
  },
  {
    icon: Mail,
    label: "email",
    value: "alaasedeek07@gmail.com",
    href: "mailto:alaasedeek07@gmail.com",
  },
];

export default function Contact() {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-80px" });

  return (
    <section id="contact" style={{ padding: "6rem 2.5rem 8rem", borderTop: "0.5px solid rgba(29,158,117,0.1)" }}>
      <div style={{ maxWidth: "780px", margin: "0 auto" }}>
        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          style={{ marginBottom: "3rem" }}
        >
          <p style={{
            fontFamily: "'JetBrains Mono', monospace",
            fontSize: "12px", color: "#1D9E75", letterSpacing: "0.12em", marginBottom: "0.6rem",
          }}>04. get in touch</p>
          <h2 style={{ fontSize: "32px", fontWeight: 600, color: "#e8f0ec", letterSpacing: "-0.02em", marginBottom: "1rem" }}>
            contact
          </h2>
          <p style={{ fontSize: "15px", color: "#7a9a87", lineHeight: 1.7, maxWidth: "480px" }}>
            open to backend roles, data engineering opportunities, and interesting projects.
            reach out anytime.
          </p>
        </motion.div>

        <div style={{ display: "flex", flexDirection: "column", gap: "12px", maxWidth: "480px" }}>
          {contacts.map((item, i) => {
            const Icon = item.icon;
            return (
              <motion.a
                key={item.label}
                href={item.href}
                target={item.href.startsWith("http") ? "_blank" : undefined}
                rel="noopener noreferrer"
                initial={{ opacity: 0, x: -20 }}
                animate={inView ? { opacity: 1, x: 0 } : {}}
                transition={{ duration: 0.5, delay: i * 0.08 }}
                whileHover={{ x: 6, borderColor: "rgba(29,158,117,0.4)" }}
                style={{
                  display: "flex", alignItems: "center", gap: "16px",
                  padding: "16px 20px",
                  background: "rgba(255,255,255,0.02)",
                  border: "0.5px solid rgba(29,158,117,0.12)",
                  borderRadius: "8px",
                  textDecoration: "none",
                  transition: "border-color 0.2s",
                  cursor: "pointer",
                }}
              >
                <div style={{
                  width: "38px", height: "38px",
                  background: "rgba(29,158,117,0.1)",
                  borderRadius: "8px",
                  display: "flex", alignItems: "center", justifyContent: "center",
                  flexShrink: 0,
                }}>
                  <Icon size={17} color="#1D9E75" />
                </div>
                <div style={{ flex: 1 }}>
                  <div style={{
                    fontFamily: "'JetBrains Mono', monospace",
                    fontSize: "11px", color: "#4a6b5a", marginBottom: "3px", letterSpacing: "0.08em",
                  }}>{item.label}</div>
                  <div style={{ fontSize: "14px", color: "#e8f0ec", fontWeight: 500 }}>{item.value}</div>
                </div>
                <ArrowUpRight size={15} color="#4a6b5a" />
              </motion.a>
            );
          })}
        </div>
      </div>
    </section>
  );
}
