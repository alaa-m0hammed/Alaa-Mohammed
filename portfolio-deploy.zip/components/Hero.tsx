"use client";
import { motion } from "framer-motion";
import { GitFork, Code2, ArrowDown } from "lucide-react";

const fadeUp = (delay = 0) => ({
  initial: { opacity: 0, y: 30 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.7, delay, ease: "easeOut" as const },
});

export default function Hero() {
  return (
    <section
      id="about"
      style={{
        minHeight: "100vh", display: "flex", flexDirection: "column",
        justifyContent: "center", padding: "8rem 2.5rem 4rem",
        position: "relative", overflow: "hidden",
      }}
    >
      {/* ambient glow */}
      <div style={{
        position: "absolute", top: "20%", left: "50%", transform: "translateX(-50%)",
        width: "600px", height: "400px",
        background: "radial-gradient(ellipse, rgba(15,110,86,0.12) 0%, transparent 70%)",
        pointerEvents: "none",
      }} />

      <div style={{ maxWidth: "780px", position: "relative" }}>
        <motion.p
          {...fadeUp(0.1)}
          style={{
            fontFamily: "'JetBrains Mono', monospace",
            fontSize: "13px", color: "#1D9E75",
            letterSpacing: "0.12em", marginBottom: "1.5rem",
          }}
        >
          hi, I'm
        </motion.p>

        <motion.h1
          {...fadeUp(0.2)}
          style={{
            fontSize: "clamp(42px, 8vw, 80px)",
            fontWeight: 600, lineHeight: 1.0,
            color: "#e8f0ec", marginBottom: "0.4rem", letterSpacing: "-0.02em",
          }}
        >
          A&apos;laa Mohammed.
        </motion.h1>

        <motion.h2
          {...fadeUp(0.3)}
          style={{
            fontSize: "clamp(32px, 6vw, 60px)",
            fontWeight: 500, lineHeight: 1.1,
            color: "#4a6b5a", marginBottom: "2rem", letterSpacing: "-0.02em",
          }}
        >
          I build backend systems.
        </motion.h2>

        <motion.p
          {...fadeUp(0.4)}
          style={{
            fontSize: "16px", color: "#7a9a87", lineHeight: 1.8,
            maxWidth: "540px", marginBottom: "2.5rem",
          }}
        >
          CS student at HNU and Data Engineering trainee at{" "}
          <span style={{ color: "#1D9E75", fontFamily: "'JetBrains Mono', monospace", fontSize: "14px" }}>DEPI</span>.
          I build scalable APIs with{" "}
          <span style={{ color: "#e8f0ec" }}>FastAPI</span> &{" "}
          <span style={{ color: "#e8f0ec" }}>Python</span>, containerize with{" "}
          <span style={{ color: "#e8f0ec" }}>Docker</span>, and compete on{" "}
          <span style={{ color: "#1D9E75", fontFamily: "'JetBrains Mono', monospace", fontSize: "14px" }}>Codeforces</span>{" "}
          as <span style={{ color: "#e8f0ec", fontFamily: "'JetBrains Mono', monospace", fontSize: "14px" }}>BLOSSOM_12</span>.
        </motion.p>

        <motion.div
          {...fadeUp(0.5)}
          style={{ display: "flex", gap: "16px", flexWrap: "wrap" }}
        >
          <motion.a
            href="#projects"
            whileHover={{ scale: 1.03, backgroundColor: "#0F6E56" }}
            whileTap={{ scale: 0.97 }}
            style={{
              display: "inline-flex", alignItems: "center", gap: "8px",
              padding: "12px 28px", background: "transparent",
              border: "1px solid #1D9E75", borderRadius: "6px",
              color: "#1D9E75", fontSize: "14px", fontWeight: 500,
              textDecoration: "none", cursor: "pointer",
              fontFamily: "'JetBrains Mono', monospace",
              transition: "background 0.2s, color 0.2s",
            }}
          >
            view my work
          </motion.a>

          <motion.a
            href="https://github.com/alaa-m0hammed"
            target="_blank"
            rel="noopener noreferrer"
            whileHover={{ scale: 1.03, borderColor: "#1D9E75", color: "#1D9E75" }}
            whileTap={{ scale: 0.97 }}
            style={{
              display: "inline-flex", alignItems: "center", gap: "8px",
              padding: "12px 28px", background: "transparent",
              border: "1px solid rgba(255,255,255,0.1)", borderRadius: "6px",
              color: "#7a9a87", fontSize: "14px", fontWeight: 500,
              textDecoration: "none", cursor: "pointer",
              fontFamily: "'JetBrains Mono', monospace",
              transition: "border 0.2s, color 0.2s",
            }}
          >
            <GitFork size={16} />
            github
          </motion.a>
        </motion.div>
      </div>

      {/* scroll hint */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.2 }}
        style={{
          position: "absolute", bottom: "2.5rem", left: "2.5rem",
          display: "flex", alignItems: "center", gap: "8px",
          color: "#4a6b5a", fontSize: "12px",
          fontFamily: "'JetBrains Mono', monospace",
        }}
      >
        <motion.div
          animate={{ y: [0, 6, 0] }}
          transition={{ repeat: Infinity, duration: 1.6, ease: "easeInOut" }}
        >
          <ArrowDown size={14} />
        </motion.div>
        scroll
      </motion.div>
    </section>
  );
}
