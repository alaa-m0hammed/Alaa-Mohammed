"use client";
import { motion } from "framer-motion";

export default function Footer() {
  return (
    <motion.footer
      initial={{ opacity: 0 }}
      whileInView={{ opacity: 1 }}
      transition={{ duration: 0.6 }}
      style={{
        padding: "2rem 2.5rem",
        borderTop: "0.5px solid rgba(29,158,117,0.1)",
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
        flexWrap: "wrap",
        gap: "12px",
      }}
    >
      <span style={{
        fontFamily: "'JetBrains Mono', monospace",
        fontSize: "12px", color: "#4a6b5a",
      }}>
        designed & built by{" "}
        <span style={{ color: "#1D9E75" }}>A&apos;laa Mohammed</span>
      </span>
      <span style={{
        fontFamily: "'JetBrains Mono', monospace",
        fontSize: "12px", color: "#4a6b5a",
      }}>
        © 2026
      </span>
    </motion.footer>
  );
}
