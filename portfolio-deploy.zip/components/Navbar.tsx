"use client";
import { motion, useScroll, useMotionValueEvent } from "framer-motion";
import { useState } from "react";

const links = ["about", "skills", "projects", "contact"];

export default function Navbar() {
  const [hidden, setHidden] = useState(false);
  const [lastY, setLastY] = useState(0);
  const { scrollY } = useScroll();

  useMotionValueEvent(scrollY, "change", (y) => {
    setHidden(y > lastY && y > 80);
    setLastY(y);
  });

  return (
    <motion.nav
      animate={{ y: hidden ? -80 : 0 }}
      transition={{ duration: 0.3, ease: "easeInOut" }}
      style={{
        position: "fixed", top: 0, left: 0, right: 0, zIndex: 50,
        display: "flex", justifyContent: "space-between", alignItems: "center",
        padding: "1.1rem 2.5rem",
        background: "rgba(10,15,13,0.85)",
        backdropFilter: "blur(12px)",
        borderBottom: "0.5px solid rgba(29,158,117,0.15)",
      }}
    >
      <motion.a
        href="#"
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.5 }}
        style={{
          fontFamily: "'JetBrains Mono', monospace",
          fontSize: "16px", fontWeight: 500,
          color: "#1D9E75", textDecoration: "none", letterSpacing: "0.05em",
        }}
      >
        A&apos;laa Mohammed
      </motion.a>

      <motion.div
        initial={{ opacity: 0, x: 20 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.5, delay: 0.1 }}
        style={{ display: "flex", gap: "2rem" }}
      >
        {links.map((link, i) => (
          <motion.a
            key={link}
            href={`#${link}`}
            whileHover={{ color: "#1D9E75" }}
            transition={{ duration: 0.15 }}
            style={{
              fontFamily: "'JetBrains Mono', monospace",
              fontSize: "13px", color: "#7a9a87",
              textDecoration: "none", letterSpacing: "0.05em",
            }}
          >
            <span style={{ color: "#0F6E56", marginRight: "4px" }}>0{i + 1}.</span>
            {link}
          </motion.a>
        ))}
      </motion.div>
    </motion.nav>
  );
}
