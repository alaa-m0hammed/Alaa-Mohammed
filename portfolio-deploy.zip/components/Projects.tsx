"use client";
import { motion, useInView } from "framer-motion";
import { useRef } from "react";
import { GitFork, ExternalLink, ShoppingCart, UtensilsCrossed, Pill, Swords } from "lucide-react";

const iconMap: Record<string, React.ReactNode> = {
  "01": <ShoppingCart size={20} color="#1D9E75" />,
  "02": <UtensilsCrossed size={20} color="#1D9E75" />,
  "03": <Pill size={20} color="#1D9E75" />,
  "04": <Swords size={20} color="#1D9E75" />,
};

const projects = [
  {
    number: "01",
    title: "NexStore",
    description: "Full e-commerce store built from scratch — no frameworks, no libraries. Product listings, cart, filters, and checkout flow in pure HTML, CSS & JS.",
    tags: ["HTML", "CSS", "JavaScript"],
    github: "https://github.com/alaa-m0hammed",
    icon: "",
    featured: true,
  },
  {
    number: "02",
    title: "Restaurant Management System",
    description: "Java Swing desktop app with admin module — login system, employee management, meal management tabs, and reporting. Part of a 6-member team project.",
    tags: ["Java", "Swing", "OOP"],
    github: "https://github.com/alaa-m0hammed",
    icon: "",
    featured: true,
  },
  {
    number: "03",
    title: "Pharmacy System Analysis",
    description: "Full systems analysis document with UML Use Case, Activity, Class & Sequence diagrams, plus DFDs. Covers requirements elicitation and system design.",
    tags: ["UML", "Systems Analysis", "DFD"],
    github: "https://github.com/alaa-m0hammed",
    icon: "",
    featured: false,
  },
  {
    number: "04",
    title: "Al-Sibawyah — ICPC Training Group",
    description: "Co-founded a competitive programming group for HNU-FCSIT students. Organized problem sets, training plans, and contest prep sessions on Codeforces.",
    tags: ["Competitive Programming", "C++", "Codeforces"],
    github: "https://github.com/alaa-m0hammed",
    icon: "",
    featured: false,
  },
];

export default function Projects() {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-80px" });

  return (
    <section id="projects" style={{ padding: "6rem 2.5rem", borderTop: "0.5px solid rgba(29,158,117,0.1)" }}>
      <div style={{ maxWidth: "780px", margin: "0 auto" }}>
        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          style={{ marginBottom: "3rem" }}
        >
          <p style={{
            fontFamily: "'JetBrains Mono', monospace",
            fontSize: "12px", color: "#1D9E75", letterSpacing: "0.12em", marginBottom: "0.6rem",
          }}>03. what I've built</p>
          <h2 style={{ fontSize: "32px", fontWeight: 600, color: "#e8f0ec", letterSpacing: "-0.02em" }}>
            projects
          </h2>
        </motion.div>

        <div style={{ display: "flex", flexDirection: "column", gap: "20px" }}>
          {projects.map((project, i) => (
            <ProjectCard key={project.number} project={project} index={i} />
          ))}
        </div>
      </div>
    </section>
  );
}

function ProjectCard({ project, index }: { project: typeof projects[0]; index: number }) {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-40px" });

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 30 }}
      animate={inView ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 0.55, delay: index * 0.08 }}
      whileHover={{ y: -3 }}
      style={{
        background: "rgba(255,255,255,0.02)",
        border: "0.5px solid rgba(29,158,117,0.15)",
        borderRadius: "10px",
        padding: "1.6rem 2rem",
        display: "grid",
        gridTemplateColumns: "auto 1fr auto",
        gap: "1.2rem",
        alignItems: "start",
        cursor: "default",
        transition: "border-color 0.2s",
      }}
      onHoverStart={(e) => {
        (e.target as HTMLElement).closest?.('[data-card]');
      }}
    >
      {/* Number + Icon */}
      <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: "8px", paddingTop: "2px" }}>
        <span style={{
          fontFamily: "'JetBrains Mono', monospace",
          fontSize: "11px", color: "#0F6E56", letterSpacing: "0.08em",
        }}>{project.number}</span>
        <div style={{ marginTop: "4px" }}>{iconMap[project.number]}</div>
      </div>

      {/* Content */}
      <div>
        <h3 style={{
          fontSize: "17px", fontWeight: 600,
          color: "#e8f0ec", marginBottom: "8px", letterSpacing: "-0.01em",
        }}>{project.title}</h3>
        <p style={{
          fontSize: "14px", color: "#7a9a87",
          lineHeight: 1.7, marginBottom: "14px",
        }}>{project.description}</p>
        <div style={{ display: "flex", gap: "8px", flexWrap: "wrap" }}>
          {project.tags.map((tag) => (
            <span key={tag} style={{
              fontFamily: "'JetBrains Mono', monospace",
              fontSize: "11px", color: "#1D9E75",
              padding: "3px 10px",
              background: "rgba(29,158,117,0.08)",
              borderRadius: "4px",
              border: "0.5px solid rgba(29,158,117,0.2)",
            }}>{tag}</span>
          ))}
        </div>
      </div>

      {/* Links */}
      <div style={{ display: "flex", gap: "12px", paddingTop: "2px" }}>
        <motion.a
          href={project.github}
          target="_blank"
          rel="noopener noreferrer"
          whileHover={{ color: "#1D9E75", scale: 1.1 }}
          style={{ color: "#4a6b5a", transition: "color 0.15s" }}
        >
          <GitFork size={17} />
        </motion.a>
        <motion.a
          href="#"
          whileHover={{ color: "#1D9E75", scale: 1.1 }}
          style={{ color: "#4a6b5a", transition: "color 0.15s" }}
        >
          <ExternalLink size={17} />
        </motion.a>
      </div>
    </motion.div>
  );
}
